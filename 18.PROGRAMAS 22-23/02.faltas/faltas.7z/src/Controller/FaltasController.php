<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

use App\Repository\CursoRepository;
use App\Repository\AlumnoRepository;
use App\Repository\FaltaRepository;


// tipos form
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\MoneyType;

// clase
use App\Entity\Falta;
use App\Entity\Alumno;
use App\Entity\Curso;
/**
 * @Route("/faltas")
 */
class FaltasController extends AbstractController
{
    private $cursoRepository;
    private $alumnoRepository;
    private $faltaRepository;

    public function __construct( CursoRepository $cursoRepository, AlumnoRepository $alumnoRepository, FaltaRepository $faltaRepository)
    {
        $this->cursoRepository = $cursoRepository;
        $this->alumnoRepository = $alumnoRepository;
        $this->faltaRepository = $faltaRepository;
        
    }
       
    /**
     * @Route("/inicio/{curso_id}/{date}",defaults={"curso_id"=null,"date"=null } ,name="faltas_inicio")
     */
    public function index(Request $request, $curso_id, $date ): Response
    {
        $cursos = $this->cursoRepository->findAll();

        $lista_cursos = array(); 
        foreach( $cursos as $curso )
        {
            $lista_cursos[ $curso->getCurso() ] =  $curso->getId();
        }
        
        if( $curso_id == null ) // Establezco ultimo curso
        {
            $keys = array_keys($lista_cursos); // lista keys
            $curso_id = $lista_cursos[$keys[0] ];
        }

        if( $date == null )
            $fecha = new \DateTime('today');
        else
            $fecha =new  \DateTime($date);
       
        
        $listado = $this->alumnoRepository->findByCursoFaltas($curso_id, $fecha->format('Y-m-d'));
        
        $data = [ "fecha" => $fecha, "curso_id" => $curso_id ];

        $formBuilder = $this->createFormBuilder($data );
        $formBuilder->add('curso_id', ChoiceType::class, [
               'choices'  => $lista_cursos,  'data' => $curso_id ] );
        $formBuilder->add('fecha', DateType::class);
        $formBuilder->add('Send', SubmitType::class);
        
        foreach( $listado as $item )
        {
           
            $formBuilder->add('papellido' . $item[ 'alumno_id'], TextType::class, ['data' => $item[ 'papellido']]);
            $formBuilder->add('sapellido' . $item[ 'alumno_id'], TextType::class, ['data' => $item[ 'sapellido']]);
            $formBuilder->add('nombre' . $item[ 'alumno_id'], TextType::class, ['data' => $item[ 'nombre']]);
            $formBuilder->add('falta' . $item[ 'alumno_id'], ChoiceType::class, ['choices'  => [ 'yes' => true,'no' => false],'expanded' => true, 'multiple' => false, 'data' => $item[ 'fecha'] != null ? true:false ]);
            
        }

        $formBuilder->add('Aceptar', SubmitType::class);
        $form = $formBuilder->getForm();
        


        
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            
            $data = $form->getData();
            if ($form->getClickedButton() && 'Aceptar' === $form->getClickedButton()->getName()) {
                
                foreach( $listado as $item )
                {
                    if( isset( $data[ 'falta'. $item[ 'alumno_id'] ] ) )
                    {
                        echo 'falta'. $item[ 'alumno_id']. $data[ 'falta'. $item[ 'alumno_id']]. "<br>"; 
                        if( $item[ 'fecha' ]  == null  && $data['falta'. $item[ 'alumno_id'] ] == true )
                        {
                            $falta = new Falta();
                            $falta->setFecha( $fecha );
                            $alumno = $this->alumnoRepository->find( $item[ 'alumno_id']);
                            $falta->setAlumno( $alumno );
                            $this->faltaRepository->save( $falta, true);

                        }
                        elseif( $item[ 'fecha' ]  != null && $data['falta'. $item[ 'alumno_id'] ] == false )
                        {
                             $alumno = $this->alumnoRepository->find($item[ 'alumno_id'] );
                            $falta = $this->faltaRepository->findOneBy( ['fecha' => $fecha, 'alumno' => $alumno]);
                            $this->faltaRepository->remove($falta, true);

                        }

                    }
                } 
               
                return $this->redirectToRoute('faltas_inicio', ['curso_id'=>$curso_id, 'date'=>$data[ 'fecha' ]->format('Y-m-d')],); 
   
            }
            if ($form->getClickedButton() && 'Send' === $form->getClickedButton()->getName()) {
                
                
                return $this->redirectToRoute('faltas_inicio', ['curso_id'=> $data[ 'curso_id' ],'date'=>$data[ 'fecha' ]->format('Y-m-d')]); 
            }
            
        }
        return $this->render('faltas/form.html.twig', array('form' => $form->createView(),));
        
    }


    /**
     * @Route("/fin/{curso_id}/{date}",defaults={"curso_id"=null,"date"=null } ,name="faltas_inicio")
     */
    public function fin(Request $request, $curso_id, $date ): Response
    {
        $cursos = $this->cursoRepository->findAll();

        $lista_cursos = array(); 
        foreach( $cursos as $curso )
        {
            $lista_cursos[ $curso->getCurso() ] =  $curso->getId();
        }
        
        if( $curso_id == null ) // Establezco ultimo curso
        {
            $keys = array_keys($lista_cursos); // lista keys
            $curso_id = $lista_cursos[$keys[0] ];
        }

        if( $date == null )
            $fecha = new \DateTime('today');
        else
            $fecha =new  \DateTime($date);
       
        
        $listado = $this->alumnoRepository->findByCurso($curso_id);
        
        
        $data = [ "fecha" => $fecha, "curso_id" => $curso_id ];

        $formBuilder = $this->createFormBuilder($data );
        $formBuilder->add('curso_id', ChoiceType::class, [
               'choices'  => $lista_cursos,  'data' => $curso_id ] );
        $formBuilder->add('fecha', DateType::class);
        $formBuilder->add('Send', SubmitType::class);
        
        foreach( $listado as $item )
        {
           
            var_dump( serialize( $item->getFaltas()));
            
        }

        $formBuilder->add('Aceptar', SubmitType::class);
        $form = $formBuilder->getForm();
        


        
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            
            $data = $form->getData();
            if ($form->getClickedButton() && 'Aceptar' === $form->getClickedButton()->getName()) {
                
                foreach( $listado as $item )
                {
                    if( isset( $data[ 'falta'. $item[ 'alumno_id'] ] ) )
                    {
                        echo 'falta'. $item[ 'alumno_id']. $data[ 'falta'. $item[ 'alumno_id']]. "<br>"; 
                        if( $item[ 'fecha' ]  == null  && $data['falta'. $item[ 'alumno_id'] ] == true )
                        {
                            $falta = new Falta();
                            $falta->setFecha( $fecha );
                            $alumno = $this->alumnoRepository->find( $item[ 'alumno_id']);
                            $falta->setAlumno( $alumno );
                            $this->faltaRepository->save( $falta, true);

                        }
                        elseif( $item[ 'fecha' ]  != null && $data['falta'. $item[ 'alumno_id'] ] == false )
                        {
                             $alumno = $this->alumnoRepository->find($item[ 'alumno_id'] );
                            $falta = $this->faltaRepository->findOneBy( ['fecha' => $fecha, 'alumno' => $alumno]);
                            $this->faltaRepository->remove($falta, true);

                        }

                    }
                } 
               
                return $this->redirectToRoute('faltas_inicio', ['curso_id'=>$curso_id, 'date'=>$data[ 'fecha' ]->format('Y-m-d')],); 
   
            }
            if ($form->getClickedButton() && 'Send' === $form->getClickedButton()->getName()) {
                
                
                return $this->redirectToRoute('faltas_inicio', ['curso_id'=> $data[ 'curso_id' ],'date'=>$data[ 'fecha' ]->format('Y-m-d')]); 
            }
            
        }
        return $this->render('faltas/form.html.twig', array('form' => $form->createView(),));
        
    }
}