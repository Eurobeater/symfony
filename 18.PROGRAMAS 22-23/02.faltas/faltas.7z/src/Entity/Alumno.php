<?php

namespace App\Entity;

use App\Repository\AlumnoRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AlumnoRepository::class)]
class Alumno
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 255)]
    private ?string $nombre = null;

    #[ORM\Column(length: 255)]
    private ?string $papellido = null;

    #[ORM\Column(length: 255)]
    private ?string $sapellido = null;

    #[ORM\ManyToOne(inversedBy: 'alumnos')]
    private ?Curso $curso = null;

    #[ORM\OneToMany(mappedBy: 'alumno', targetEntity: Falta::class)]
    private Collection $faltas;

    public function __construct()
    {
        $this->faltas = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNombre(): ?string
    {
        return $this->nombre;
    }

    public function setNombre(string $nombre): self
    {
        $this->nombre = $nombre;

        return $this;
    }

    public function getPapellido(): ?string
    {
        return $this->papellido;
    }

    public function setPapellido(string $papellido): self
    {
        $this->papellido = $papellido;

        return $this;
    }

    public function getSapellido(): ?string
    {
        return $this->sapellido;
    }

    public function setSapellido(string $sapellido): self
    {
        $this->sapellido = $sapellido;

        return $this;
    }

    public function getCurso(): ?Curso
    {
        return $this->curso;
    }

    public function setCurso(?Curso $curso): self
    {
        $this->curso = $curso;

        return $this;
    }

    /**
     * @return Collection<int, Falta>
     */
    public function getFaltas(): Collection
    {
        return $this->faltas;
    }

    public function addFalta(Falta $falta): self
    {
        if (!$this->faltas->contains($falta)) {
            $this->faltas->add($falta);
            $falta->setAlumno($this);
        }

        return $this;
    }

    public function removeFalta(Falta $falta): self
    {
        if ($this->faltas->removeElement($falta)) {
            // set the owning side to null (unless already changed)
            if ($falta->getAlumno() === $this) {
                $falta->setAlumno(null);
            }
        }

        return $this;
    }
}
