<?php

namespace App\Repository;

use App\Entity\Alumno;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Alumno>
 *
 * @method Alumno|null find($id, $lockMode = null, $lockVersion = null)
 * @method Alumno|null findOneBy(array $criteria, array $orderBy = null)
 * @method Alumno[]    findAll()
 * @method Alumno[]    findBy(array $criteria, array $orderBy = null, $limit = null, $offset = null)
 */
class AlumnoRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Alumno::class);
    }

    public function save(Alumno $entity, bool $flush = false): void
    {
        $this->getEntityManager()->persist($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }

    public function remove(Alumno $entity, bool $flush = false): void
    {
        $this->getEntityManager()->remove($entity);

        if ($flush) {
            $this->getEntityManager()->flush();
        }
    }
    /*public function findByCursoFaltas($curso_id, $fecha)
    {
        $conn = $this->getEntityManager()
            ->getConnection();
        $sql = "SELECT  *,  alumno.id as alumno_id FROM `alumno` left join falta on alumno.id = falta.alumno_id where curso_id = ? and ( fecha = ? or fecha is null ) order by papellido, sapellido, nombre";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue( 1, $curso_id );
        $stmt->bindValue( 2, $fecha  );
        $result = $stmt->executeQuery();
        $listado = $result->fetchAllAssociative();
        
        return($listado);

    }
    */

    public function findByCursoFaltas($curso_id, $fecha)
    {
        $conn = $this->getEntityManager()->getConnection();
        $sql = "SELECT  *,  alumno.id as alumno_id FROM alumno  where curso_id = ? order by papellido, sapellido, nombre, id";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(1, $curso_id);
        $result = $stmt->executeQuery();
        $alumnos = $result->fetchAllAssociative();

        $sql = "SELECT *, alumno.id as alumno_id FROM alumno INNER join falta on alumno.id = falta.alumno_id where curso_id = ? and falta.fecha = ? order by papellido, sapellido, nombre, alumno.id";
        $stmt = $conn->prepare($sql);
        $stmt->bindValue(1, $curso_id);
        $stmt->bindValue(2, $fecha);
        $result = $stmt->executeQuery();
        $faltas = $result->fetchAllAssociative();

        for ($i = 0; $i < count($alumnos); $i++) {
            $alumnos[$i]['fecha'] = null;
            foreach ($faltas as $falta) {
                if ($falta['alumno_id'] == $alumnos[$i]['alumno_id']) {
                    $alumnos[$i]['fecha'] = $falta['fecha'];
                    break;
                }
            }
        }

        return ($alumnos);
    }
    //    /**
    //     * @return Alumno[] Returns an array of Alumno objects
    //     */
    //    public function findByExampleField($value): array
    //    {
    //        return $this->createQueryBuilder('a')
    //            ->andWhere('a.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->orderBy('a.id', 'ASC')
    //            ->setMaxResults(10)
    //            ->getQuery()
    //            ->getResult()
    //        ;
    //    }

    //    public function findOneBySomeField($value): ?Alumno
    //    {
    //        return $this->createQueryBuilder('a')
    //            ->andWhere('a.exampleField = :val')
    //            ->setParameter('val', $value)
    //            ->getQuery()
    //            ->getOneOrNullResult()
    //        ;
    //    }
}
